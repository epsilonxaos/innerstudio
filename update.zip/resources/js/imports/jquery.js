const $ = require('jquery');
window.jQuery = $;

export {$};