<!-- <svg width="382px" height="448px" viewBox="0 0 382 448" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" data-toggle="modal" data-btn="#mdSeleccion">
    <title>Seleccion de tapete</title
    <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
        <g id="1.0-Reservarpower" transform="translate(-609.000000, -356.000000)">
            <g id="Group-15" transform="translate(-300.000000, 281.000000)">
                <g id="Group-14" transform="translate(909.000000, 75.000000)">
                    <g id="Group-5" transform="translate(15.000000, 416.000000)">
                        <rect id="Rectangle" stroke="#2B2B2B" stroke-width="2" fill="#FBB790" x="1" y="1" width="50" height="30"></rect>
                        <text id="1" font-family="Poppins-Medium, Poppins" font-size="12" font-weight="400" letter-spacing="0.6864" fill="#2B2B2B">
                            <tspan x="24.0568" y="21">1</tspan>
                        </text>
                    </g>
                    <g id="Group-5" transform="translate(15.000000, 372.000000)">
                        <rect id="Rectangle" stroke="#2B2B2B" stroke-width="2" fill="#FBB790" x="1" y="1" width="50" height="30"></rect>
                        <text id="2" font-family="Poppins-Medium, Poppins" font-size="12" font-weight="400" letter-spacing="0.6864" fill="#2B2B2B">
                            <tspan x="22.6948" y="21">2</tspan>
                        </text>
                    </g>
                    <g id="Group-5" transform="translate(15.000000, 328.000000)">
                        <rect id="Rectangle" stroke="#2B2B2B" stroke-width="2" fill="#FBB790" x="1" y="1" width="50" height="30"></rect>
                        <text id="3" font-family="Poppins-Medium, Poppins" font-size="12" font-weight="400" letter-spacing="0.6864" fill="#2B2B2B">
                            <tspan x="22.5928" y="21">3</tspan>
                        </text>
                    </g>
                    <g id="Group-16" transform="translate(15.000000, 284.000000)">
                        <rect id="Rectangle" stroke="#2B2B2B" stroke-width="2" fill="#FBB790" x="1" y="1" width="50" height="30"></rect>
                        <text id="4" font-family="Poppins-Medium, Poppins" font-size="12" font-weight="400" letter-spacing="0.6864" fill="#2B2B2B">
                            <tspan x="22.2748" y="21">4</tspan>
                        </text>
                    </g>
                    <g id="Group-5" transform="translate(15.000000, 152.000000)">
                        <rect id="Rectangle" stroke="#2B2B2B" stroke-width="2" fill="#FBB790" x="1" y="1" width="50" height="30"></rect>
                        <text id="7" font-family="Poppins-Medium, Poppins" font-size="12" font-weight="400" letter-spacing="0.6864" fill="#2B2B2B">
                            <tspan x="22.7968" y="21">7</tspan>
                        </text>
                    </g>
                    <g id="Group-5" transform="translate(15.000000, 108.000000)">
                        <rect id="Rectangle" stroke="#2B2B2B" stroke-width="2" fill="#FBB790" x="1" y="1" width="50" height="30"></rect>
                        <text id="8" font-family="Poppins-Medium, Poppins" font-size="12" font-weight="400" letter-spacing="0.6864" fill="#2B2B2B">
                            <tspan x="22.3288" y="21">8</tspan>
                        </text>
                    </g>
                    <g id="Group-5" transform="translate(15.000000, 64.000000)">
                        <rect id="Rectangle" stroke="#2B2B2B" stroke-width="2" fill="#FBB790" x="1" y="1" width="50" height="30"></rect>
                        <text id="9" font-family="Poppins-Medium, Poppins" font-size="12" font-weight="400" letter-spacing="0.6864" fill="#2B2B2B">
                            <tspan x="22.3468" y="21">9</tspan>
                        </text>
                    </g>
                    <g id="Group-5" transform="translate(316.000000, 108.000000)">
                        <rect id="Rectangle" stroke="#2B2B2B" stroke-width="2" fill="#FBB790" x="1" y="1" width="50" height="30"></rect>
                        <text id="17" font-family="Poppins-Medium, Poppins" font-size="12" font-weight="400" letter-spacing="0.6864" fill="#2B2B2B">
                            <tspan x="20.3536" y="21">17</tspan>
                        </text>
                    </g>
                    <g id="Group-5" transform="translate(316.000000, 328.000000)">
                        <rect id="Rectangle" stroke="#2B2B2B" stroke-width="2" fill="#FBB790" x="1" y="1" width="50" height="30"></rect>
                        <text id="22" font-family="Poppins-Medium, Poppins" font-size="12" font-weight="400" letter-spacing="0.6864" fill="#2B2B2B">
                            <tspan x="18.8896" y="21">22</tspan>
                        </text>
                    </g>
                    <g id="Group-5" transform="translate(316.000000, 372.000000)">
                        <rect id="Rectangle" stroke="#2B2B2B" stroke-width="2" fill="#FBB790" x="1" y="1" width="50" height="30"></rect>
                        <text id="23" font-family="Poppins-Medium, Poppins" font-size="12" font-weight="400" letter-spacing="0.6864" fill="#2B2B2B">
                            <tspan x="18.7876" y="21">23</tspan>
                        </text>
                    </g>
                    <g id="Group-5" transform="translate(316.000000, 416.000000)">
                        <rect id="Rectangle" stroke="#2B2B2B" stroke-width="2" fill="#FBB790" x="1" y="1" width="50" height="30"></rect>
                        <text id="24" font-family="Poppins-Medium, Poppins" font-size="12" font-weight="400" letter-spacing="0.6864" fill="#2B2B2B">
                            <tspan x="18.4696" y="21">24</tspan>
                        </text>
                    </g>
                    <g id="Group-5" transform="translate(316.000000, 64.000000)">
                        <rect id="Rectangle" stroke="#2B2B2B" stroke-width="2" fill="#FBB790" x="1" y="1" width="50" height="30"></rect>
                        <text id="16" font-family="Poppins-Medium, Poppins" font-size="12" font-weight="400" letter-spacing="0.6864" fill="#2B2B2B">
                            <tspan x="19.8616" y="21">16</tspan>
                        </text>
                    </g>
                    <g id="Group-5" transform="translate(196.000000, 20.000000)">
                        <rect id="Rectangle" stroke="#2B2B2B" stroke-width="2" fill="#FBB790" x="1" y="1" width="50" height="30"></rect>
                        <text id="13" font-family="Poppins-Medium, Poppins" font-size="12" font-weight="400" letter-spacing="0.6864" fill="#2B2B2B">
                            <tspan x="20.1496" y="21">13</tspan>
                        </text>
                    </g>
                    <g id="Group-5" transform="translate(256.000000, 20.000000)">
                        <rect id="Rectangle" stroke="#2B2B2B" stroke-width="2" fill="#FBB790" x="1" y="1" width="50" height="30"></rect>
                        <text id="14" font-family="Poppins-Medium, Poppins" font-size="12" font-weight="400" letter-spacing="0.6864" fill="#2B2B2B">
                            <tspan x="19.8316" y="21">14</tspan>
                        </text>
                    </g>
                    <g id="Group-16" transform="translate(15.000000, 20.000000)">
                        <rect id="Rectangle" stroke="#2B2B2B" stroke-width="2" fill="#FBB790" x="1" y="1" width="50" height="30"></rect>
                        <text id="10" font-family="Poppins-Medium, Poppins" font-size="12" font-weight="400" letter-spacing="0.6864" fill="#2B2B2B">
                            <tspan x="19.8676" y="21">10</tspan>
                        </text>
                    </g>
                    <g id="Group-5" transform="translate(15.000000, 196.000000)">
                        <rect id="Rectangle" stroke="#2B2B2B" stroke-width="2" fill="#746A68" x="1" y="1" width="50" height="30"></rect>
                        <text id="6" font-family="Poppins-Medium, Poppins" font-size="12" font-weight="400" letter-spacing="0.6864" fill="#FFFFFF">
                            <tspan x="22.3048" y="20">6</tspan>
                        </text>
                    </g>
                    <g id="Group-5" transform="translate(15.000000, 240.000000)">
                        <rect id="Rectangle" stroke="#2B2B2B" stroke-width="2" fill="#746A68" x="1" y="1" width="50" height="30"></rect>
                        <text id="5" font-family="Poppins-Medium, Poppins" font-size="12" font-weight="400" letter-spacing="0.6864" fill="#FFFFFF">
                            <tspan x="22.3228" y="21">5</tspan>
                        </text>
                    </g>
                    <g id="Group-5" transform="translate(75.000000, 20.000000)">
                        <rect id="Rectangle" stroke="#2B2B2B" stroke-width="2" fill="#746A68" x="1" y="1" width="50" height="30"></rect>
                        <text id="11" font-family="Poppins-Medium, Poppins" font-size="12" font-weight="400" letter-spacing="0.6864" fill="#FFFFFF">
                            <tspan x="21.6136" y="20">11</tspan>
                        </text>
                    </g>
                    <g id="Group-5" transform="translate(316.000000, 20.000000)">
                        <rect id="Rectangle" stroke="#2B2B2B" stroke-width="2" fill="#746A68" x="1" y="1" width="50" height="30"></rect>
                        <text id="15" font-family="Poppins-Medium, Poppins" font-size="12" font-weight="400" letter-spacing="0.6864" fill="#FFFFFF">
                            <tspan x="19.8796" y="20">15</tspan>
                        </text>
                    </g>
                    <g id="Group-5" transform="translate(316.000000, 152.000000)">
                        <rect id="Rectangle" stroke="#2B2B2B" stroke-width="2" fill="#746A68" x="1" y="1" width="50" height="30"></rect>
                        <text id="18" font-family="Poppins-Medium, Poppins" font-size="12" font-weight="400" letter-spacing="0.6864" fill="#FFFFFF">
                            <tspan x="19.8856" y="20">18</tspan>
                        </text>
                    </g>
                    <g id="Group-5" transform="translate(316.000000, 196.000000)">
                        <rect id="Rectangle" stroke="#2B2B2B" stroke-width="2" fill="#746A68" x="1" y="1" width="50" height="30"></rect>
                        <text id="19" font-family="Poppins-Medium, Poppins" font-size="12" font-weight="400" letter-spacing="0.6864" fill="#FFFFFF">
                            <tspan x="19.9036" y="20">19</tspan>
                        </text>
                    </g>
                    <g id="Group-5" transform="translate(316.000000, 240.000000)">
                        <rect id="Rectangle" stroke="#2B2B2B" stroke-width="2" fill="#746A68" x="1" y="1" width="50" height="30"></rect>
                        <text id="20" font-family="Poppins-Medium, Poppins" font-size="12" font-weight="400" letter-spacing="0.6864" fill="#FFFFFF">
                            <tspan x="18.5056" y="20">20</tspan>
                        </text>
                    </g>
                    <g id="Group-5" transform="translate(316.000000, 284.000000)">
                        <rect id="Rectangle" stroke="#2B2B2B" stroke-width="2" fill="#746A68" x="1" y="1" width="50" height="30"></rect>
                        <text id="21" font-family="Poppins-Medium, Poppins" font-size="12" font-weight="400" letter-spacing="0.6864" fill="#FFFFFF">
                            <tspan x="20.2516" y="20">21</tspan>
                        </text>
                    </g>
                    <g id="Group-5" transform="translate(135.000000, 20.000000)">
                        <rect id="Rectangle" stroke="#2B2B2B" stroke-width="2" fill="#746A68" x="1" y="1" width="50" height="30"></rect>
                        <text id="12" font-family="Poppins-Medium, Poppins" font-size="12" font-weight="400" letter-spacing="0.6864" fill="#FFFFFF">
                            <tspan x="20.2516" y="21">12</tspan>
                        </text>
                    </g>
                    <rect id="Rectangle" stroke="#2B2B2B" stroke-width="2" fill="#FFFFFF" x="1" y="16" width="4" height="431" rx="2"></rect>
                    <rect id="Rectangle" stroke="#2B2B2B" stroke-width="2" fill="#FFFFFF" transform="translate(191.000000, 3.000000) rotate(-270.000000) translate(-191.000000, -3.000000) " x="189" y="-181" width="4" height="368" rx="2"></rect>
                    <rect id="Rectangle" stroke="#2B2B2B" stroke-width="2" fill="#FFFFFF" x="377" y="16" width="4" height="431" rx="2"></rect>
                </g>
            </g>
        </g>
    </g>
</svg> -->
<!-- Generator: Adobe Illustrator 22.1.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1" id="Capa_2" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 382 463" style="enable-background:new 0 0 382 463;{{($click >= 4 )? 'pointer-events: none;' :''}}" xml:space="preserve" >
<style type="text/css">
	.st0{fill:none;stroke:#1D1D1B;stroke-miterlimit:10;}
	.st1{fill:none;stroke:#1D1D1B;stroke-width:1.0015;stroke-miterlimit:10;}
	.st2{fill:none;stroke:#1D1D1B;stroke-width:0.9248;stroke-miterlimit:10;}
    .disp{fill: #FBB790;stroke: #1D1D1B;}
    .ocup{fill: #746a68;stroke: #1D1D1B;}
    .text{fill: white;}
</style>
<rect id="_x31_1" x="316" y="20.1"  width="52" height="32" class="st0 {{in_array(11,$mats)? 'ocup': 'disp'}} {{in_array(11,$mats_disabled)? 'ocup': 'disp'}}"  data-place="11" data-btn="{{(Auth::check())? (in_array(11,$mats)? 'una' : 'mat'): (in_array(11,$mats)? 'una' : 'guest')}}{{(in_array(11,$mats_disabled)? 'una' : '')}}"/>
<rect id="_x31_2" x="316" y="63.8"  width="52" height="32" class="st0 {{in_array(12,$mats)? 'ocup': 'disp'}} {{in_array(12,$mats_disabled)? 'ocup': 'disp'}}"  data-place="12" data-btn="{{(Auth::check())? (in_array(12,$mats)? 'una' : 'mat'): (in_array(12,$mats)? 'una' : 'guest')}}{{(in_array(12,$mats_disabled)? 'una' : '')}}"/>
<rect id="_x31_3" x="316" y="108.1"  width="52" height="32" class="st0 {{in_array(13,$mats)? 'ocup': 'disp'}} {{in_array(13,$mats_disabled)? 'ocup': 'disp'}}" data-place="13"  data-btn="{{(Auth::check())? (in_array(13,$mats)? 'una' : 'mat'): (in_array(13,$mats)? 'una' : 'guest')}}{{(in_array(13,$mats_disabled)? 'una' : '')}}"/>
<rect id="_x31_4" x="316" y="151.8"  width="52" height="32" class="st0 {{in_array(14,$mats)? 'ocup': 'disp'}} {{in_array(14,$mats_disabled)? 'ocup': 'disp'}}" data-place="14"  data-btn="{{(Auth::check())? (in_array(14,$mats)? 'una' : 'mat'): (in_array(14,$mats)? 'una' : 'guest')}}{{(in_array(14,$mats_disabled)? 'una' : '')}}"/>
<rect id="_x31_5" x="316" y="196.1"  width="52" height="32" class="st0 {{in_array(15,$mats)? 'ocup': 'disp'}} {{in_array(15,$mats_disabled)? 'ocup': 'disp'}}" data-place="15"  data-btn="{{(Auth::check())? (in_array(15,$mats)? 'una' : 'mat'): (in_array(15,$mats)? 'una' : 'guest')}}{{(in_array(15,$mats_disabled)? 'una' : '')}}"/>
<rect id="_x31_6" x="316" y="239.8"  width="52" height="32" class="st0 {{in_array(16,$mats)? 'ocup': 'disp'}} {{in_array(16,$mats_disabled)? 'ocup': 'disp'}}" data-place="16"  data-btn="{{(Auth::check())? (in_array(16,$mats)? 'una' : 'mat'): (in_array(16,$mats)? 'una' : 'guest')}}{{(in_array(16,$mats_disabled)? 'una' : '')}}"/>
<rect id="_x31_7" x="316" y="284.1"  width="52" height="32" class="st0 {{in_array(17,$mats)? 'ocup': 'disp'}} {{in_array(17,$mats_disabled)? 'ocup': 'disp'}}" data-place="17"  data-btn="{{(Auth::check())? (in_array(17,$mats)? 'una' : 'mat'): (in_array(17,$mats)? 'una' : 'guest')}}{{(in_array(17,$mats_disabled)? 'una' : '')}}"/>
<rect id="_x31_8" x="316" y="327.8"  width="52" height="32" class="st0 {{in_array(18,$mats)? 'ocup': 'disp'}} {{in_array(18,$mats_disabled)? 'ocup': 'disp'}}" data-place="18"  data-btn="{{(Auth::check())? (in_array(18,$mats)? 'una' : 'mat'): (in_array(18,$mats)? 'una' : 'guest')}}{{(in_array(18,$mats_disabled)? 'una' : '')}}"/>
<rect id="_x31_9" x="316" y="372.1"  width="52" height="32" class="st0 {{in_array(19,$mats)? 'ocup': 'disp'}} {{in_array(19,$mats_disabled)? 'ocup': 'disp'}}" data-place="19"  data-btn="{{(Auth::check())? (in_array(19,$mats)? 'una' : 'mat'): (in_array(19,$mats)? 'una' : 'guest')}}{{(in_array(19,$mats_disabled)? 'una' : '')}}"/>
<rect id="_x32_0" x="316" y="415.8"  width="52" height="32" class="st0 {{in_array(20,$mats)? 'ocup': 'disp'}} {{in_array(20,$mats_disabled)? 'ocup': 'disp'}}" data-place="20"  data-btn="{{(Auth::check())? (in_array(20,$mats)? 'una' : 'mat'): (in_array(20,$mats)? 'una' : 'guest')}}{{(in_array(20,$mats_disabled)? 'una' : '')}}"/>
<rect id="_x31_0" x="14.8" y="20.1"  width="52" height="32" class="st0 {{in_array(10,$mats)? 'ocup': 'disp'}} {{in_array(10,$mats_disabled)? 'ocup': 'disp'}}" data-place="10"  data-btn="{{(Auth::check())? (in_array(10,$mats)? 'una' : 'mat'): (in_array(10,$mats)? 'una' : 'guest')}}{{(in_array(10,$mats_disabled)? 'una' : '')}}"/>
<rect id="_x39_" x="14.8" y="63.8"  width="52" height="32" class="st0 {{in_array(9,$mats)? 'ocup': 'disp'}} {{in_array(9,$mats_disabled)? 'ocup': 'disp'}}"  data-place="9" data-btn="{{(Auth::check())? (in_array(9,$mats)? 'una' : 'mat'): (in_array(9,$mats)? 'una' : 'guest')}}{{(in_array(9,$mats_disabled)? 'una' : '')}}"/>
<rect id="_x38_" x="14.8" y="108.1"  width="52" height="32" class="st0 {{in_array(8,$mats)? 'ocup': 'disp'}} {{in_array(8,$mats_disabled)? 'ocup': 'disp'}}" data-place="8"  data-btn="{{(Auth::check())? (in_array(8,$mats)? 'una' : 'mat'): (in_array(8,$mats)? 'una' : 'guest')}}{{(in_array(8,$mats_disabled)? 'una' : '')}}"/>
<rect id="_x37_" x="14.8" y="151.8"  width="52" height="32" class="st0 {{in_array(7,$mats)? 'ocup': 'disp'}} {{in_array(7,$mats_disabled)? 'ocup': 'disp'}}" data-place="7"  data-btn="{{(Auth::check())? (in_array(7,$mats)? 'una' : 'mat'): (in_array(7,$mats)? 'una' : 'guest')}}{{(in_array(7,$mats_disabled)? 'una' : '')}}"/>
<rect id="_x36_" x="14.8" y="196.1"  width="52" height="32" class="st0 {{in_array(6,$mats)? 'ocup': 'disp'}} {{in_array(6,$mats_disabled)? 'ocup': 'disp'}}" data-place="6"  data-btn="{{(Auth::check())? (in_array(6,$mats)? 'una' : 'mat'): (in_array(6,$mats)? 'una' : 'guest')}}{{(in_array(6,$mats_disabled)? 'una' : '')}}"/>
<rect id="_x35_" x="14.8" y="239.8"  width="52" height="32" class="st0 {{in_array(5,$mats)? 'ocup': 'disp'}} {{in_array(5,$mats_disabled)? 'ocup': 'disp'}}" data-place="5"  data-btn="{{(Auth::check())? (in_array(5,$mats)? 'una' : 'mat'): (in_array(5,$mats)? 'una' : 'guest')}}{{(in_array(5,$mats_disabled)? 'una' : '')}}"/>
<rect id="_x34_" x="14.8" y="284.1"  width="52" height="32" class="st0 {{in_array(4,$mats)? 'ocup': 'disp'}} {{in_array(4,$mats_disabled)? 'ocup': 'disp'}}" data-place="4"  data-btn="{{(Auth::check())? (in_array(4,$mats)? 'una' : 'mat'): (in_array(4,$mats)? 'una' : 'guest')}}{{(in_array(4,$mats_disabled)? 'una' : '')}}"/>
<rect id="_x33_" x="14.8" y="327.8"  width="52" height="32" class="st0 {{in_array(3,$mats)? 'ocup': 'disp'}} {{in_array(3,$mats_disabled)? 'ocup': 'disp'}}" data-place="3"  data-btn="{{(Auth::check())? (in_array(3,$mats)? 'una' : 'mat'): (in_array(3,$mats)? 'una' : 'guest')}}{{(in_array(3,$mats_disabled)? 'una' : '')}}"/>
<rect id="_x32_" x="14.8" y="372.1"  width="52" height="32" class="st0 {{in_array(2,$mats)? 'ocup': 'disp'}} {{in_array(2,$mats_disabled)? 'ocup': 'disp'}}" data-place="2"  data-btn="{{(Auth::check())? (in_array(2,$mats)? 'una' : 'mat'): (in_array(2,$mats)? 'una' : 'guest')}}{{(in_array(2,$mats_disabled)? 'una' : '')}}"/>
<rect id="_x31_" x="14.8" y="415.8"  width="52" height="32" class="st0 {{in_array(1,$mats)? 'ocup': 'disp'}} {{in_array(1,$mats_disabled)? 'ocup': 'disp'}}" data-place="1"  data-btn="{{(Auth::check())? (in_array(1,$mats)? 'una' : 'mat'): (in_array(1,$mats)? 'una' : 'guest')}}{{(in_array(1,$mats_disabled)? 'una' : '')}}"/>
<!-- <rect id="_x32_5" x="255.8" y="415.8" class="st0" width="52" height="32"/>
<rect id="_x32_6" x="196" y="415.8" class="st0" width="52" height="32"/>
<rect id="_x32_7" x="135" y="415.8" class="st0" width="52" height="32"/>
<rect id="_x32_8" x="74.8" y="415.8" class="st0" width="52" height="32"/>
<rect id="_x32_4" x="255.8" y="20.1" class="st0" width="52" height="32"/>
<rect id="_x32_3" x="196" y="20.1" class="st0" width="52" height="32"/>
<rect id="_x32_2" x="135" y="20.1" class="st0" width="52" height="32"/>
<rect id="_x32_1" x="74.8" y="20.1" class="st0" width="52" height="32"/> -->
<path class="st1" d="M4.7,447.3L4.7,447.3c-0.9,0-1.7-0.8-1.7-1.7V17.7c0-0.9,0.7-1.7,1.7-1.7h0c0.9,0,1.7,0.8,1.7,1.7v427.9
	C6.3,446.6,5.6,447.3,4.7,447.3z"/>
<path class="st1" d="M378,447.3L378,447.3c-0.9,0-1.7-0.8-1.7-1.7V17.7c0-0.9,0.8-1.7,1.7-1.7l0,0c0.9,0,1.7,0.8,1.7,1.7v427.9
	C379.7,446.6,378.9,447.3,378,447.3z"/>
<path class="st2" d="M6.5,3.3V3.1c0-0.8,0.7-1.5,1.5-1.5h364.7c0.8,0,1.5,0.7,1.5,1.5v0.3c0,0.8-0.7,1.5-1.5,1.5H8.1
	C7.2,4.9,6.5,4.2,6.5,3.3z"/>
<path class="st2" d="M6.5,459.3v-0.3c0-0.8,0.7-1.5,1.5-1.5h364.7c0.8,0,1.5,0.7,1.5,1.5v0.3c0,0.8-0.7,1.5-1.5,1.5H8.1
	C7.2,460.9,6.5,460.2,6.5,459.3z"/>
<g class="{{in_array(10,$mats)? 'text': ''}}">
	<path d="M34.7,33.2v-1.6h3v8.5H36v-6.9H34.7z"/>
	<path d="M39.1,35.8c0-2.9,1.1-4.3,3.2-4.3c1.1,0,2,0.4,2.5,1.2s0.8,1.8,0.8,3.1c0,1.3-0.3,2.4-0.8,3.2s-1.3,1.2-2.5,1.2
		C40.1,40.1,39.1,38.6,39.1,35.8z M43.9,35.8c0-0.9-0.1-1.5-0.3-2c-0.2-0.5-0.6-0.7-1.2-0.7c-0.6,0-1,0.2-1.3,0.7
		c-0.2,0.5-0.3,1.1-0.3,2c0,0.9,0.1,1.5,0.3,2c0.2,0.5,0.6,0.7,1.3,0.7c0.6,0,1-0.2,1.2-0.7C43.8,37.3,43.9,36.6,43.9,35.8z"/>
</g>
<!-- <g>
	<path d="M100.7,34c0-0.4-0.1-0.7-0.3-0.9c-0.2-0.2-0.5-0.3-0.8-0.3c-0.8,0-1.2,0.5-1.3,1.6h-1.6c0-1,0.4-1.8,0.9-2.3
		s1.3-0.8,2.1-0.8c0.9,0,1.5,0.2,2,0.7c0.5,0.5,0.7,1.1,0.7,1.8c0,0.6-0.2,1.2-0.5,1.8c-0.3,0.6-0.8,1.1-1.3,1.6
		c-0.5,0.5-1.1,0.9-1.7,1.3h3.7V40h-6v-1.3C99.4,36.8,100.7,35.3,100.7,34z"/>
	<path d="M103.1,33.2v-1.6h3v8.5h-1.8v-6.9H103.1z"/>
</g> -->
<!-- <g>
	<path d="M159,34c0-0.4-0.1-0.7-0.3-0.9c-0.2-0.2-0.5-0.3-0.8-0.3c-0.8,0-1.2,0.5-1.3,1.6H155c0-1,0.4-1.8,0.9-2.3s1.3-0.8,2.1-0.8
		c0.9,0,1.5,0.2,2,0.7c0.5,0.5,0.7,1.1,0.7,1.8c0,0.6-0.2,1.2-0.5,1.8c-0.3,0.6-0.8,1.1-1.3,1.6c-0.5,0.5-1.1,0.9-1.7,1.3h3.7V40h-6
		v-1.3C157.7,36.8,159,35.3,159,34z"/>
	<path d="M165.8,34c0-0.4-0.1-0.7-0.3-0.9c-0.2-0.2-0.5-0.3-0.8-0.3c-0.8,0-1.2,0.5-1.3,1.6h-1.6c0-1,0.4-1.8,0.9-2.3
		s1.3-0.8,2.1-0.8c0.9,0,1.5,0.2,2,0.7c0.5,0.5,0.7,1.1,0.7,1.8c0,0.6-0.2,1.2-0.5,1.8c-0.3,0.6-0.8,1.1-1.3,1.6
		c-0.5,0.5-1.1,0.9-1.7,1.3h3.7V40h-6v-1.3C164.5,36.8,165.8,35.3,165.8,34z"/>
</g> -->
<!-- <g>
	<path d="M219,34c0-0.4-0.1-0.7-0.3-0.9c-0.2-0.2-0.5-0.3-0.8-0.3c-0.8,0-1.2,0.5-1.3,1.6H215c0-1,0.4-1.8,0.9-2.3s1.3-0.8,2.1-0.8
		c0.9,0,1.5,0.2,2,0.7c0.5,0.5,0.7,1.1,0.7,1.8c0,0.6-0.2,1.2-0.5,1.8c-0.3,0.6-0.8,1.1-1.3,1.6c-0.5,0.5-1.1,0.9-1.7,1.3h3.7V40h-6
		v-1.3C217.7,36.8,219,35.3,219,34z"/>
	<path d="M226.4,31.6c0.4,0.2,0.7,0.5,0.9,0.8s0.3,0.7,0.3,1.2c0,0.5-0.1,1-0.4,1.3c-0.3,0.3-0.7,0.6-1.2,0.6v0.1
		c1.2,0.4,1.8,1,1.8,2.1c0,0.7-0.2,1.3-0.7,1.8c-0.5,0.5-1.2,0.7-2.1,0.7c-0.9,0-1.7-0.2-2.3-0.7c-0.6-0.5-0.9-1.2-0.9-2.1h1.7
		c0,0.4,0.2,0.8,0.4,1c0.2,0.3,0.6,0.4,1,0.4c0.4,0,0.7-0.1,0.9-0.3c0.2-0.2,0.3-0.5,0.3-0.8c0-0.4-0.2-0.7-0.5-0.9
		c-0.3-0.2-0.8-0.3-1.4-0.3H224v-1.4h0.3c1.1,0,1.7-0.4,1.7-1.2c0-0.3-0.1-0.6-0.3-0.8c-0.2-0.2-0.5-0.3-0.8-0.3
		c-0.4,0-0.7,0.1-0.9,0.3s-0.4,0.5-0.4,1H222c0-0.9,0.3-1.5,0.8-2c0.5-0.5,1.2-0.7,2.1-0.7C225.5,31.3,226,31.4,226.4,31.6z"/>
</g> -->
<!-- <g>
	<path d="M279.7,34c0-0.4-0.1-0.7-0.3-0.9c-0.2-0.2-0.5-0.3-0.8-0.3c-0.8,0-1.2,0.5-1.3,1.6h-1.6c0-1,0.4-1.8,0.9-2.3
		s1.3-0.8,2.1-0.8c0.9,0,1.5,0.2,2,0.7c0.5,0.5,0.7,1.1,0.7,1.8c0,0.6-0.2,1.2-0.5,1.8c-0.3,0.6-0.8,1.1-1.3,1.6
		c-0.5,0.5-1.1,0.9-1.7,1.3h3.7V40h-6v-1.3C278.4,36.8,279.7,35.3,279.7,34z"/>
	<path d="M282.5,38.4V37l4.1-5.5h1.8v5.4h1.1v1.5h-1.1v1.7h-1.7v-1.7H282.5z M286.8,33.5l-2.6,3.4h2.6V33.5z"/>
</g> -->
<g class="{{in_array(11,$mats)? 'text': ''}}">
	<path d="M338,33.2v-1.6h3v8.5h-1.8v-6.9H338z"/>
	<path d="M342,33.2v-1.6h3v8.5h-1.8v-6.9H342z"/>
</g>
<g class="{{in_array(12,$mats)? 'text': ''}}">
	<path d="M337,77.5v-1.6h3v8.5h-1.8v-6.9H337z"/>
	<path d="M345.3,78.4c0-0.4-0.1-0.7-0.3-0.9c-0.2-0.2-0.5-0.3-0.8-0.3c-0.8,0-1.2,0.5-1.3,1.6h-1.6c0-1,0.4-1.8,0.9-2.3
		s1.3-0.8,2.1-0.8c0.9,0,1.5,0.2,2,0.7c0.5,0.5,0.7,1.1,0.7,1.8c0,0.6-0.2,1.2-0.5,1.8c-0.3,0.6-0.8,1.1-1.3,1.6
		c-0.5,0.5-1.1,0.9-1.7,1.3h3.7v1.4h-6v-1.3C344,81.2,345.3,79.6,345.3,78.4z"/>
</g>
<g class="{{in_array(13,$mats)? 'text': ''}}">
	<path d="M337,121.7v-1.6h3v8.5h-1.8v-6.9H337z"/>
	<path d="M345.9,120.1c0.4,0.2,0.7,0.5,0.9,0.8s0.3,0.7,0.3,1.2c0,0.5-0.1,1-0.4,1.3c-0.3,0.3-0.7,0.6-1.2,0.6v0.1
		c1.2,0.4,1.8,1,1.8,2.1c0,0.7-0.2,1.3-0.7,1.8c-0.5,0.5-1.2,0.7-2.1,0.7c-0.9,0-1.7-0.2-2.3-0.7c-0.6-0.5-0.9-1.2-0.9-2.1h1.7
		c0,0.4,0.2,0.8,0.4,1c0.2,0.3,0.6,0.4,1,0.4c0.4,0,0.7-0.1,0.9-0.3c0.2-0.2,0.3-0.5,0.3-0.8c0-0.4-0.2-0.7-0.5-0.9
		c-0.3-0.2-0.8-0.3-1.4-0.3h-0.3v-1.4h0.3c1.1,0,1.7-0.4,1.7-1.2c0-0.3-0.1-0.6-0.3-0.8c-0.2-0.2-0.5-0.3-0.8-0.3
		c-0.4,0-0.7,0.1-0.9,0.3s-0.4,0.5-0.4,1h-1.7c0-0.9,0.3-1.5,0.8-2c0.5-0.5,1.2-0.7,2.1-0.7C345,119.8,345.5,119.9,345.9,120.1z"/>
</g>
<g class="{{in_array(14,$mats)? 'text': ''}}">
	<path d="M337,164.4v-1.6h3v8.5h-1.8v-6.9H337z"/>
	<path d="M341.3,169.5v-1.4l4.1-5.5h1.8v5.4h1.1v1.5h-1.1v1.7h-1.7v-1.7H341.3z M345.6,164.7l-2.6,3.4h2.6V164.7z"/>
</g>
<g class="{{in_array(15,$mats)? 'text': ''}}">
	<path d="M337,208.7v-1.6h3v8.5h-1.8v-6.9H337z"/>
	<path d="M347.5,208.4h-4v2.1c0.2-0.2,0.4-0.4,0.8-0.5c0.3-0.1,0.7-0.2,1.1-0.2c0.6,0,1.1,0.1,1.5,0.4s0.7,0.6,0.9,1
		c0.2,0.4,0.3,0.9,0.3,1.4c0,0.9-0.3,1.6-0.8,2.2c-0.5,0.5-1.2,0.8-2.2,0.8c-0.6,0-1.2-0.1-1.6-0.3s-0.8-0.5-1.1-0.9
		c-0.3-0.4-0.4-0.9-0.4-1.4h1.6c0.1,0.4,0.2,0.6,0.4,0.9c0.2,0.2,0.5,0.3,0.9,0.3c0.5,0,0.8-0.1,1-0.4c0.2-0.3,0.3-0.7,0.3-1.1
		c0-0.4-0.1-0.8-0.4-1c-0.2-0.2-0.6-0.4-1-0.4c-0.3,0-0.6,0.1-0.8,0.2c-0.2,0.1-0.4,0.3-0.5,0.6h-1.6v-5h5.6V208.4z"/>
</g>
<g class="{{in_array(16,$mats)? 'text': ''}}">
	<path d="M337,252.7v-1.6h3v8.5h-1.8v-6.9H337z"/>
	<path d="M344.6,252.2c-0.6,0-1,0.2-1.2,0.7c-0.3,0.5-0.4,1.3-0.3,2.3c0.1-0.4,0.4-0.7,0.8-0.9c0.4-0.2,0.8-0.3,1.3-0.3
		c0.8,0,1.5,0.2,1.9,0.7c0.5,0.5,0.7,1.2,0.7,2.1c0,0.6-0.1,1.1-0.3,1.5s-0.6,0.8-1,1c-0.4,0.2-1,0.4-1.6,0.4
		c-1.2,0-2.1-0.4-2.5-1.1c-0.5-0.8-0.7-1.8-0.7-3.2c0-1.5,0.2-2.7,0.8-3.4c0.5-0.7,1.3-1.1,2.4-1.1c0.9,0,1.5,0.2,2,0.7
		c0.5,0.5,0.7,1.1,0.8,1.9h-1.6C345.8,252.6,345.3,252.2,344.6,252.2z M343.6,257.8c0.3,0.3,0.6,0.4,1.1,0.4c0.4,0,0.8-0.1,1-0.4
		c0.3-0.3,0.4-0.6,0.4-1.1c0-0.5-0.1-0.8-0.4-1.1c-0.3-0.3-0.6-0.4-1-0.4c-0.4,0-0.8,0.1-1.1,0.4c-0.3,0.2-0.4,0.6-0.4,1
		C343.2,257.1,343.3,257.5,343.6,257.8z"/>
</g>
<g class="{{in_array(17,$mats)? 'text': ''}}">
	<path d="M337,296.4v-1.6h3v8.5h-1.8v-6.9H337z"/>
	<path d="M346.7,296l-3.1,7.3h-1.8l3.1-7.1H341v-1.5h5.6V296z"/>
</g>
<g class="{{in_array(18,$mats)? 'text': ''}}">
	<path d="M337,341.4v-1.6h3v8.5h-1.8v-6.9H337z"/>
	<path d="M342,340.6c0.2-0.4,0.6-0.6,1-0.9c0.5-0.2,1-0.3,1.6-0.3s1.2,0.1,1.6,0.3c0.5,0.2,0.8,0.5,1,0.9c0.2,0.4,0.3,0.7,0.3,1.1
		c0,0.5-0.1,0.9-0.3,1.2c-0.2,0.3-0.6,0.6-1,0.7c0.5,0.2,0.9,0.5,1.2,0.8c0.3,0.4,0.4,0.8,0.4,1.3c0,0.6-0.1,1-0.4,1.4
		c-0.3,0.4-0.7,0.7-1.1,0.9s-1,0.3-1.6,0.3s-1.2-0.1-1.6-0.3c-0.5-0.2-0.9-0.5-1.1-0.9s-0.4-0.9-0.4-1.4c0-0.5,0.1-1,0.4-1.3
		c0.3-0.4,0.7-0.6,1.2-0.8c-0.4-0.2-0.8-0.4-1-0.7s-0.3-0.7-0.3-1.2C341.6,341.3,341.8,340.9,342,340.6z M343.5,346.7
		c0.3,0.2,0.7,0.4,1.1,0.4s0.9-0.1,1.1-0.4s0.4-0.6,0.4-1c0-0.4-0.1-0.8-0.4-1c-0.3-0.2-0.7-0.3-1.1-0.3c-0.5,0-0.8,0.1-1.1,0.3
		s-0.4,0.6-0.4,1C343.1,346.1,343.2,346.4,343.5,346.7z M343.7,342.9c0.2,0.2,0.6,0.3,1,0.3c0.4,0,0.7-0.1,1-0.3
		c0.2-0.2,0.4-0.5,0.4-0.9c0-0.4-0.1-0.7-0.4-0.9c-0.2-0.2-0.6-0.3-1-0.3c-0.4,0-0.7,0.1-1,0.3c-0.2,0.2-0.4,0.5-0.4,0.9
		C343.3,342.4,343.4,342.7,343.7,342.9z"/>
</g>
<g class="{{in_array(19,$mats)? 'text': ''}}">
	<path d="M337,385.6V384h3v8.5h-1.8v-6.9H337z"/>
	<path d="M344.5,391.2c0.6,0,1-0.2,1.2-0.7c0.2-0.5,0.4-1.3,0.3-2.3c-0.1,0.4-0.4,0.7-0.8,0.9s-0.8,0.3-1.3,0.3
		c-0.8,0-1.5-0.2-1.9-0.7c-0.5-0.5-0.7-1.2-0.7-2.1c0-0.6,0.1-1,0.3-1.5s0.6-0.8,1-1c0.4-0.2,1-0.4,1.6-0.4c1.2,0,2.1,0.4,2.5,1.1
		s0.7,1.8,0.7,3.1c0,1.5-0.2,2.7-0.7,3.4c-0.5,0.8-1.2,1.2-2.3,1.2c-0.6,0-1.1-0.1-1.5-0.3c-0.4-0.2-0.7-0.5-1-0.9s-0.4-0.8-0.4-1.3
		h1.6C343.3,390.8,343.7,391.2,344.5,391.2z M345.5,385.6c-0.3-0.3-0.6-0.4-1.1-0.4c-0.4,0-0.8,0.1-1,0.4c-0.3,0.3-0.4,0.6-0.4,1.1
		c0,0.5,0.1,0.9,0.4,1.1c0.3,0.3,0.6,0.4,1,0.4c0.4,0,0.8-0.1,1.1-0.4c0.3-0.2,0.5-0.6,0.5-1C345.9,386.2,345.7,385.9,345.5,385.6z"
		/>
</g>
<g class="{{in_array(20,$mats)? 'text': ''}}">
	<path d="M341.4,430.8c0-0.4-0.1-0.7-0.3-0.9c-0.2-0.2-0.5-0.3-0.8-0.3c-0.8,0-1.2,0.5-1.3,1.6h-1.6c0-1,0.4-1.8,0.9-2.3
		s1.3-0.8,2.1-0.8c0.9,0,1.5,0.2,2,0.7c0.5,0.5,0.7,1.1,0.7,1.8c0,0.6-0.2,1.2-0.5,1.8c-0.3,0.6-0.8,1.1-1.3,1.6
		c-0.5,0.5-1.1,0.9-1.7,1.3h3.7v1.4h-6v-1.3C340,433.6,341.4,432,341.4,430.8z"/>
	<path d="M344.2,432.5c0-2.9,1.1-4.3,3.2-4.3c1.1,0,2,0.4,2.5,1.2s0.8,1.8,0.8,3.1c0,1.3-0.3,2.4-0.8,3.2s-1.3,1.2-2.5,1.2
		C345.3,436.8,344.2,435.3,344.2,432.5z M349,432.5c0-0.9-0.1-1.5-0.3-2c-0.2-0.5-0.6-0.7-1.2-0.7c-0.6,0-1,0.2-1.3,0.7
		c-0.2,0.5-0.3,1.1-0.3,2c0,0.9,0.1,1.5,0.3,2c0.2,0.5,0.6,0.7,1.3,0.7c0.6,0,1-0.2,1.2-0.7C348.9,434,349,433.3,349,432.5z"/>
</g>
<g class="{{in_array(9,$mats)? 'text': ''}}">
	<path d="M41.2,84.1c0.6,0,1-0.2,1.2-0.7c0.2-0.5,0.4-1.3,0.3-2.3c-0.1,0.4-0.4,0.7-0.8,0.9s-0.8,0.3-1.3,0.3
		c-0.8,0-1.5-0.2-1.9-0.7c-0.5-0.5-0.7-1.2-0.7-2.1c0-0.6,0.1-1,0.3-1.5s0.6-0.8,1-1c0.4-0.2,1-0.4,1.6-0.4c1.2,0,2.1,0.4,2.5,1.1
		s0.7,1.8,0.7,3.1c0,1.5-0.2,2.7-0.7,3.4c-0.5,0.8-1.2,1.2-2.3,1.2c-0.6,0-1.1-0.1-1.5-0.3c-0.4-0.2-0.7-0.5-1-0.9s-0.4-0.8-0.4-1.3
		h1.6C40,83.7,40.4,84.1,41.2,84.1z M42.2,78.5c-0.3-0.3-0.6-0.4-1.1-0.4c-0.4,0-0.8,0.1-1,0.4c-0.3,0.3-0.4,0.6-0.4,1.1
		c0,0.5,0.1,0.9,0.4,1.1c0.3,0.3,0.6,0.4,1,0.4c0.4,0,0.8-0.1,1.1-0.4c0.3-0.2,0.5-0.6,0.5-1C42.6,79.2,42.4,78.8,42.2,78.5z"/>
</g>
<g class="{{in_array(8,$mats)? 'text': ''}}">
	<path d="M38.7,121.4c0.2-0.4,0.6-0.6,1-0.9c0.5-0.2,1-0.3,1.6-0.3s1.2,0.1,1.6,0.3c0.5,0.2,0.8,0.5,1,0.9c0.2,0.4,0.3,0.7,0.3,1.1
		c0,0.5-0.1,0.9-0.3,1.2c-0.2,0.3-0.6,0.6-1,0.7c0.5,0.2,0.9,0.5,1.2,0.8c0.3,0.4,0.4,0.8,0.4,1.3c0,0.6-0.1,1-0.4,1.4
		c-0.3,0.4-0.7,0.7-1.1,0.9s-1,0.3-1.6,0.3s-1.2-0.1-1.6-0.3c-0.5-0.2-0.9-0.5-1.1-0.9s-0.4-0.9-0.4-1.4c0-0.5,0.1-1,0.4-1.3
		c0.3-0.4,0.7-0.6,1.2-0.8c-0.4-0.2-0.8-0.4-1-0.7s-0.3-0.7-0.3-1.2C38.4,122.1,38.5,121.7,38.7,121.4z M40.2,127.5
		c0.3,0.2,0.7,0.4,1.1,0.4s0.9-0.1,1.1-0.4s0.4-0.6,0.4-1c0-0.4-0.1-0.8-0.4-1c-0.3-0.2-0.7-0.3-1.1-0.3c-0.5,0-0.8,0.1-1.1,0.3
		s-0.4,0.6-0.4,1C39.8,126.9,39.9,127.2,40.2,127.5z M40.4,123.7c0.2,0.2,0.6,0.3,1,0.3c0.4,0,0.7-0.1,1-0.3
		c0.2-0.2,0.4-0.5,0.4-0.9c0-0.4-0.1-0.7-0.4-0.9c-0.2-0.2-0.6-0.3-1-0.3c-0.4,0-0.7,0.1-1,0.3c-0.2,0.2-0.4,0.5-0.4,0.9
		C40,123.2,40.1,123.5,40.4,123.7z"/>
</g>
<g class="{{in_array(7,$mats)? 'text': ''}}">
	<path d="M43.4,165.4l-3.1,7.3h-1.8l3.1-7.1h-3.9v-1.5h5.6V165.4z"/>
</g>
<g class="{{in_array(6,$mats)? 'text': ''}}">
	<path d="M41.3,208.7c-0.6,0-1,0.2-1.2,0.7c-0.3,0.5-0.4,1.3-0.3,2.3c0.1-0.4,0.4-0.7,0.8-0.9c0.4-0.2,0.8-0.3,1.3-0.3
		c0.8,0,1.5,0.2,1.9,0.7c0.5,0.5,0.7,1.2,0.7,2.1c0,0.6-0.1,1.1-0.3,1.5s-0.6,0.8-1,1c-0.4,0.2-1,0.4-1.6,0.4
		c-1.2,0-2.1-0.4-2.5-1.1c-0.5-0.8-0.7-1.8-0.7-3.2c0-1.5,0.2-2.7,0.8-3.4c0.5-0.7,1.3-1.1,2.4-1.1c0.9,0,1.5,0.2,2,0.7
		c0.5,0.5,0.7,1.1,0.8,1.9h-1.6C42.5,209.1,42,208.7,41.3,208.7z M40.3,214.3c0.3,0.3,0.6,0.4,1.1,0.4c0.4,0,0.8-0.1,1-0.4
		c0.3-0.3,0.4-0.6,0.4-1.1c0-0.5-0.1-0.8-0.4-1.1c-0.3-0.3-0.6-0.4-1-0.4c-0.4,0-0.8,0.1-1.1,0.4c-0.3,0.2-0.4,0.6-0.4,1
		C39.9,213.6,40,214,40.3,214.3z"/>
</g>
<g class="{{in_array(5,$mats)? 'text': ''}}">
	<path d="M44.2,253.6h-4v2.1c0.2-0.2,0.4-0.4,0.8-0.5c0.3-0.1,0.7-0.2,1.1-0.2c0.6,0,1.1,0.1,1.5,0.4s0.7,0.6,0.9,1
		c0.2,0.4,0.3,0.9,0.3,1.4c0,0.9-0.3,1.6-0.8,2.2c-0.5,0.5-1.2,0.8-2.2,0.8c-0.6,0-1.2-0.1-1.6-0.3s-0.8-0.5-1.1-0.9
		c-0.3-0.4-0.4-0.9-0.4-1.4h1.6c0.1,0.4,0.2,0.6,0.4,0.9c0.2,0.2,0.5,0.3,0.9,0.3c0.5,0,0.8-0.1,1-0.4c0.2-0.3,0.3-0.7,0.3-1.1
		c0-0.4-0.1-0.8-0.4-1c-0.2-0.2-0.6-0.4-1-0.4c-0.3,0-0.6,0.1-0.8,0.2c-0.2,0.1-0.4,0.3-0.5,0.6h-1.6v-5h5.6V253.6z"/>
</g>
<g class="{{in_array(4,$mats)? 'text': ''}}">
	<path d="M38,302.7v-1.4l4.1-5.5h1.8v5.4H45v1.5h-1.1v1.7h-1.7v-1.7H38z M42.3,297.9l-2.6,3.4h2.6V297.9z"/>
</g>
<g class="{{in_array(3,$mats)? 'text': ''}}">
	<path d="M42.6,340.6c0.4,0.2,0.7,0.5,0.9,0.8s0.3,0.7,0.3,1.2c0,0.5-0.1,1-0.4,1.3c-0.3,0.3-0.7,0.6-1.2,0.6v0.1
		c1.2,0.4,1.8,1,1.8,2.1c0,0.7-0.2,1.3-0.7,1.8c-0.5,0.5-1.2,0.7-2.1,0.7c-0.9,0-1.7-0.2-2.3-0.7c-0.6-0.5-0.9-1.2-0.9-2.1h1.7
		c0,0.4,0.2,0.8,0.4,1c0.2,0.3,0.6,0.4,1,0.4c0.4,0,0.7-0.1,0.9-0.3c0.2-0.2,0.3-0.5,0.3-0.8c0-0.4-0.2-0.7-0.5-0.9
		c-0.3-0.2-0.8-0.3-1.4-0.3h-0.3V344h0.3c1.1,0,1.7-0.4,1.7-1.2c0-0.3-0.1-0.6-0.3-0.8c-0.2-0.2-0.5-0.3-0.8-0.3
		c-0.4,0-0.7,0.1-0.9,0.3s-0.4,0.5-0.4,1h-1.7c0-0.9,0.3-1.5,0.8-2c0.5-0.5,1.2-0.7,2.1-0.7C41.7,340.3,42.2,340.4,42.6,340.6z"/>
</g>
<g class="{{in_array(2,$mats)? 'text': ''}}">
	<path d="M42,387.4c0-0.4-0.1-0.7-0.3-0.9c-0.2-0.2-0.5-0.3-0.8-0.3c-0.8,0-1.2,0.5-1.3,1.6H38c0-1,0.4-1.8,0.9-2.3s1.3-0.8,2.1-0.8
		c0.9,0,1.5,0.2,2,0.7c0.5,0.5,0.7,1.1,0.7,1.8c0,0.6-0.2,1.2-0.5,1.8c-0.3,0.6-0.8,1.1-1.3,1.6c-0.5,0.5-1.1,0.9-1.7,1.3h3.7v1.4
		h-6v-1.3C40.7,390.2,42,388.7,42,387.4z"/>
</g>
<g class="{{in_array(1,$mats)? 'text': ''}}">
	<path d="M37.7,430.6V429h3v8.5H39v-6.9H37.7z"/>
</g>
<!-- <g>
	<path d="M280.2,431.2c0-0.4-0.1-0.7-0.3-0.9c-0.2-0.2-0.5-0.3-0.8-0.3c-0.8,0-1.2,0.5-1.3,1.6h-1.6c0-1,0.4-1.8,0.9-2.3
		s1.3-0.8,2.1-0.8c0.9,0,1.5,0.2,2,0.7c0.5,0.5,0.7,1.1,0.7,1.8c0,0.6-0.2,1.2-0.5,1.8c-0.3,0.6-0.8,1.1-1.3,1.6
		c-0.5,0.5-1.1,0.9-1.7,1.3h3.7v1.4h-6v-1.3C278.8,434,280.2,432.5,280.2,431.2z"/>
	<path d="M289.1,430.1h-4v2.1c0.2-0.2,0.4-0.4,0.8-0.5c0.3-0.1,0.7-0.2,1.1-0.2c0.6,0,1.1,0.1,1.5,0.4s0.7,0.6,0.9,1
		c0.2,0.4,0.3,0.9,0.3,1.4c0,0.9-0.3,1.6-0.8,2.2c-0.5,0.5-1.2,0.8-2.2,0.8c-0.6,0-1.2-0.1-1.6-0.3s-0.8-0.5-1.1-0.9
		c-0.3-0.4-0.4-0.9-0.4-1.4h1.6c0.1,0.4,0.2,0.6,0.4,0.9c0.2,0.2,0.5,0.3,0.9,0.3c0.5,0,0.8-0.1,1-0.4c0.2-0.3,0.3-0.7,0.3-1.1
		c0-0.4-0.1-0.8-0.4-1c-0.2-0.2-0.6-0.4-1-0.4c-0.3,0-0.6,0.1-0.8,0.2c-0.2,0.1-0.4,0.3-0.5,0.6h-1.6v-5h5.6V430.1z"/>
</g> -->
<!-- <g>
	<path d="M219.5,431.2c0-0.4-0.1-0.7-0.3-0.9c-0.2-0.2-0.5-0.3-0.8-0.3c-0.8,0-1.2,0.5-1.3,1.6h-1.6c0-1,0.4-1.8,0.9-2.3
		s1.3-0.8,2.1-0.8c0.9,0,1.5,0.2,2,0.7c0.5,0.5,0.7,1.1,0.7,1.8c0,0.6-0.2,1.2-0.5,1.8c-0.3,0.6-0.8,1.1-1.3,1.6
		c-0.5,0.5-1.1,0.9-1.7,1.3h3.7v1.4h-6v-1.3C218.1,434,219.5,432.5,219.5,431.2z"/>
	<path d="M225.6,429.8c-0.6,0-1,0.2-1.2,0.7c-0.3,0.5-0.4,1.3-0.3,2.3c0.1-0.4,0.4-0.7,0.8-0.9c0.4-0.2,0.8-0.3,1.3-0.3
		c0.8,0,1.5,0.2,1.9,0.7c0.5,0.5,0.7,1.2,0.7,2.1c0,0.6-0.1,1.1-0.3,1.5s-0.6,0.8-1,1c-0.4,0.2-1,0.4-1.6,0.4
		c-1.2,0-2.1-0.4-2.5-1.1c-0.5-0.8-0.7-1.8-0.7-3.2c0-1.5,0.2-2.7,0.8-3.4c0.5-0.7,1.3-1.1,2.4-1.1c0.9,0,1.5,0.2,2,0.7
		c0.5,0.5,0.7,1.1,0.8,1.9h-1.6C226.7,430.2,226.3,429.8,225.6,429.8z M224.5,435.4c0.3,0.3,0.6,0.4,1.1,0.4c0.4,0,0.8-0.1,1-0.4
		c0.3-0.3,0.4-0.6,0.4-1.1c0-0.5-0.1-0.8-0.4-1.1c-0.3-0.3-0.6-0.4-1-0.4c-0.4,0-0.8,0.1-1.1,0.4c-0.3,0.2-0.4,0.6-0.4,1
		C224.1,434.8,224.3,435.2,224.5,435.4z"/>
</g> -->
<!-- <g>
	<path d="M159.8,431.2c0-0.4-0.1-0.7-0.3-0.9c-0.2-0.2-0.5-0.3-0.8-0.3c-0.8,0-1.2,0.5-1.3,1.6h-1.6c0-1,0.4-1.8,0.9-2.3
		s1.3-0.8,2.1-0.8c0.9,0,1.5,0.2,2,0.7c0.5,0.5,0.7,1.1,0.7,1.8c0,0.6-0.2,1.2-0.5,1.8c-0.3,0.6-0.8,1.1-1.3,1.6
		c-0.5,0.5-1.1,0.9-1.7,1.3h3.7v1.4h-6v-1.3C158.5,434,159.8,432.5,159.8,431.2z"/>
	<path d="M167.9,430l-3.1,7.3h-1.8l3.1-7.1h-3.9v-1.5h5.6V430z"/>
</g> -->
<!-- <g>
	<path d="M98.8,429.6c0-0.4-0.1-0.7-0.3-0.9c-0.2-0.2-0.5-0.3-0.8-0.3c-0.8,0-1.2,0.5-1.3,1.6h-1.6c0-1,0.4-1.8,0.9-2.3
		s1.3-0.8,2.1-0.8c0.9,0,1.5,0.2,2,0.7c0.5,0.5,0.7,1.1,0.7,1.8c0,0.6-0.2,1.2-0.5,1.8c-0.3,0.6-0.8,1.1-1.3,1.6
		c-0.5,0.5-1.1,0.9-1.7,1.3h3.7v1.4h-6v-1.3C97.5,432.4,98.8,430.8,98.8,429.6z"/>
	<path d="M102.3,427.9c0.2-0.4,0.6-0.6,1-0.9c0.5-0.2,1-0.3,1.6-0.3s1.2,0.1,1.6,0.3c0.5,0.2,0.8,0.5,1,0.9c0.2,0.4,0.3,0.7,0.3,1.1
		c0,0.5-0.1,0.9-0.3,1.2c-0.2,0.3-0.6,0.6-1,0.7c0.5,0.2,0.9,0.5,1.2,0.8c0.3,0.4,0.4,0.8,0.4,1.3c0,0.6-0.1,1-0.4,1.4
		c-0.3,0.4-0.7,0.7-1.1,0.9s-1,0.3-1.6,0.3s-1.2-0.1-1.6-0.3c-0.5-0.2-0.9-0.5-1.1-0.9s-0.4-0.9-0.4-1.4c0-0.5,0.1-1,0.4-1.3
		c0.3-0.4,0.7-0.6,1.2-0.8c-0.4-0.2-0.8-0.4-1-0.7s-0.3-0.7-0.3-1.2C101.9,428.6,102,428.3,102.3,427.9z M103.8,434
		c0.3,0.2,0.7,0.4,1.1,0.4s0.9-0.1,1.1-0.4s0.4-0.6,0.4-1c0-0.4-0.1-0.8-0.4-1c-0.3-0.2-0.7-0.3-1.1-0.3c-0.5,0-0.8,0.1-1.1,0.3
		s-0.4,0.6-0.4,1C103.4,433.4,103.5,433.8,103.8,434z M104,430.2c0.2,0.2,0.6,0.3,1,0.3c0.4,0,0.7-0.1,1-0.3
		c0.2-0.2,0.4-0.5,0.4-0.9c0-0.4-0.1-0.7-0.4-0.9c-0.2-0.2-0.6-0.3-1-0.3c-0.4,0-0.7,0.1-1,0.3c-0.2,0.2-0.4,0.5-0.4,0.9
		C103.6,429.7,103.7,430,104,430.2z"/>
</g> -->
</svg>
